package config;

public class AppCtx {
}
